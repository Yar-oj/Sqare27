using System;
using UnityEngine;
using UnityEngine.EventSystems;

public class SkipScript : MonoBehaviour
{
    [Header("Настройки")]
    public float requiredHoldTime = 2.0f;

    private bool isHolding = false;
    private float holdTimer = 0.0f;

    void Update()
    {
        if (isHolding)
        {
            holdTimer += Time.deltaTime;
            

            if (holdTimer >= requiredHoldTime)
            {
                SceneManager.Instance.switchScene(1);
                ResetHold();
            }
        }
    }

    public void OnMosueDown()
    {
        Debug.Log("Нажатие");
        isHolding = true;
    }

    public void OnMouseUp()
    {
        ResetHold();
    }

    private void ResetHold()
    {
        isHolding = false;
        holdTimer = 0.0f;
    }
}