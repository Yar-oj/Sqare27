using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneManager : MonoBehaviour
{

    public TextManager sceneText;
    public SpriteRenderer introImage;
    public AudioSource audioManager;

    public static SceneManager Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
    }

    public void switchScene(int num)
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(num);
    }

    public IEnumerator IntroRoutine()
    {

        sceneText.ShowText("***\nНедалеко от границы.\nЗона ответственности - сто двадцать километров на восток.\nКвадрат, который я знаю наизусть.");

        yield return new WaitForSeconds(5f);

        sceneText.ShowText("***\nВсего часик, по ППМ и смена.\nЧасик в небе, часик тишины. Потом чай, рапорт, и на боковую");

        yield return new WaitForSeconds(5f);

        sceneText.ShowText("***\n...");

        yield return new WaitForSeconds(3f);

        sceneText.ShowText("");

        audioManager.Play();

        yield return new WaitForSeconds(26f);

        Color color = introImage.color;
        color.a = 0f;
        introImage.color = color;
        introImage.gameObject.SetActive(true);

        float elapsedTime = 0f;
        while (elapsedTime < 5f)
        {
            elapsedTime += Time.deltaTime;
            color.a = Mathf.Clamp01(elapsedTime / 5f);
            introImage.color = color;
            yield return null;
        }

        color.a = 1f;
        introImage.color = color;


        sceneText.ShowText("***\nСтарт, борт два-четыре-четыре-восемь. Запуск по готовности. Прошу разрешение.");

        yield return new WaitForSeconds(4f);

        sceneText.ShowText("---\nДва-четыре-четыре-восемь, Старт. Запуск разрешаю.\nПолоса два-семь, ветер три-два-ноль, три метра в секунду.\nДавление семь-четыре-ноль.");

        yield return new WaitForSeconds(7f);

        sceneText.ShowText("***\nЗапуск, два-семь, семь-четыре-ноль. Принял.");

        yield return new WaitForSeconds(3f);

        sceneText.ShowText("");

        elapsedTime = 0;
        while (elapsedTime < 3f)
        {
            elapsedTime += Time.deltaTime;
            color.a = 1 - Mathf.Clamp01(elapsedTime / 3f);
            introImage.color = color;
            yield return null;
        }

        introImage.sprite = Resources.Load<Sprite>("IntroImages/monolog2");

        elapsedTime = 0;
        while (elapsedTime < 5f)
        {
            elapsedTime += Time.deltaTime;
            color.a = Mathf.Clamp01(elapsedTime / 5f);
            introImage.color = color;
            yield return null;
        }


        yield return new WaitForSeconds(4f);

        sceneText.ShowText("");

        yield return new WaitForSeconds(4f);

        sceneText.ShowText("---\nРуление, рулёжка три.\n\n***\nПонял.");

        yield return new WaitForSeconds(3f);

        sceneText.ShowText("");

        yield return new WaitForSeconds(10f);

        sceneText.ShowText("***\nСтарт, два-четыре-четыре-восемь. На предварительном. Готов к взлёту.");

        yield return new WaitForSeconds(5f);

        sceneText.ShowText("---\nДва-четыре-четыре-восемь, полоса свободна. Взлёт разрешаю. \nПосле отрыва - связь на Круг, частота сто двадцать четыре и шесть.");

        yield return new WaitForSeconds(5f);

        sceneText.ShowText("***\nДва-четыре-четыре-восемь принял");

        yield return new WaitForSeconds(3f);

        sceneText.ShowText("");

        elapsedTime = 0;
        while (elapsedTime < 3f)
        {
            elapsedTime += Time.deltaTime;
            color.a = 1 - Mathf.Clamp01(elapsedTime / 3f);
            introImage.color = color;
            yield return null;
        }

        introImage.sprite = Resources.Load<Sprite>("IntroImages/monolog3");

        elapsedTime = 0;
        while (elapsedTime < 5f)
        {
            elapsedTime += Time.deltaTime;
            color.a = Mathf.Clamp01(elapsedTime / 5f);
            introImage.color = color;
            yield return null;
        }


    sceneText.ShowText("---\nДва-четыре-четыре-восемь, Круг. Вижу вас. \nНабирайте пять тысяч, курс ноль-девять-ноль. \nЗона патрулирования - квадрат '27'");

    yield return new WaitForSeconds(5f);

    sceneText.ShowText("***\nПять тысяч, ноль-девять-ноль, квадрат '27'. Принял.");

    yield return new WaitForSeconds(4f);

    sceneText.ShowText("");

    elapsedTime = 0;
        while (elapsedTime < 3f)
        {
            elapsedTime += Time.deltaTime;
            color.a = 1 - Mathf.Clamp01(elapsedTime / 3f);
            introImage.color = color;
            yield return null;
        }

        introImage.sprite = Resources.Load<Sprite>("IntroImages/monolog4");

        elapsedTime = 0;
        while (elapsedTime < 5f)
        {
            elapsedTime += Time.deltaTime;
            color.a = Mathf.Clamp01(elapsedTime / 5f);
            introImage.color = color;
            yield return null;
        }

    yield return new WaitForSeconds(8f);

    sceneText.ShowText("***\nПять тысяч. Небо чистое.\nВидимость - до горизонта и дальше.");

    yield return new WaitForSeconds(5f);

    sceneText.ShowText("***\nГраница внизу - тонкая линия на земле, которой на самом деле нет.\nНо за неё нельзя.\nИ с той стороны - тоже нельзя.");

    yield return new WaitForSeconds(6f);

    sceneText.ShowText("***\nКрасиво здесь. Каждый раз одно и то же, и каждый раз - по-разному.\nОблака сегодня низкие, тени длинные");

    yield return new WaitForSeconds(4f);

    audioManager.Stop();

    sceneText.ShowText("...");

    yield return new WaitForSeconds(4f);

    sceneText.ShowText("");

    yield return new WaitForSeconds(6f);

    sceneText.ShowText("###\nДва-четыре-четыре-восемь, Контакт!\nАзимут ноль-шесть-пять, дальность восемьдесят,\nвысота семь тысяч. Скорость - девятьсот.\nДвижется к границе.");

    yield return new WaitForSeconds(7f);

    sceneText.ShowText("###\nДва-четыре-четыре-восемь, курс на перехват - ноль-шесть-пять.\nНабирайте семь тысяч. Готовность к визуальному опознанию.");

    yield return new WaitForSeconds(6f);

    sceneText.ShowText("***\nВот и часик прошёл.");

    yield return new WaitForSeconds(3f);

    sceneText.ShowText("...");

    yield return new WaitForSeconds(3f);

    sceneText.ShowText("...");

    yield return new WaitForSeconds(3f);

    sceneText.ShowText("...");

    yield return new WaitForSeconds(3f);

    sceneText.ShowText("");

    yield return new WaitForSeconds(4f);

    sceneText.ShowText("***\nА вот и ты...");

    yield return new WaitForSeconds(3f);

    sceneText.ShowText("");

    AudioClip loadedClip = Resources.Load<AudioClip>("RWR");
    audioManager.clip = loadedClip;

    introImage.sprite = Resources.Load<Sprite>("IntroImages/monolog5");
    audioManager.Play();

    
    yield return new WaitForSeconds(6f);

    introImage.gameObject.SetActive(false);

    switchScene(1);

    }
    

    
    void Start()
    {
        StartCoroutine(IntroRoutine());
    }
}