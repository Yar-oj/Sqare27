using UnityEngine;
using System.Collections;

public class BattleBox : MonoBehaviour
{
    private Coroutine resizeCoroutine;

    [SerializeField]
    private Vector2 center;
    [SerializeField]
    private Vector2 size;
    private LineRenderer lineRenderer;

    public void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
    }
    public void Update()
    {
        UpdateBoundaries();
    }

    private IEnumerator ResizeRoutine(Vector2 targetCenter, Vector2 targetSize, float duration)
    {
        Vector2 startCenter = center;
        Vector2 startSize = size;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            float smoothT = Mathf.SmoothStep(0f, 1f, t);
            center = Vector2.Lerp(startCenter, targetCenter, smoothT);
            size = Vector2.Lerp(startSize, targetSize, smoothT);
            yield return null;
        }

        center = targetCenter;
        size = targetSize;
    }

    public void SetDimensions(Vector2 newCenter, Vector2 newSize, float duration)
    {
        if (resizeCoroutine != null) StopCoroutine(resizeCoroutine);
        resizeCoroutine = StartCoroutine(ResizeRoutine(newCenter, newSize, duration));

    }
    public Vector2 GetCenter() => center;
    public Vector2 GetSize() => size;

    private void UpdateBoundaries()
    {
        Vector3 topLeft = new Vector3(
            center.x - size.x / 2,
            center.y + size.y / 2
        );
        Vector3 topRight = new Vector3(
            center.x + size.x / 2,
            center.y + size.y / 2
        );
        Vector3 bottomRight = new Vector3(
            center.x + size.x / 2,
            center.y - size.y / 2
        );
        Vector3 bottomLeft = new Vector3(
            center.x - size.x / 2,
            center.y - size.y / 2
        );
        lineRenderer.SetPosition(0, topLeft);
        lineRenderer.SetPosition(1, topRight);
        lineRenderer.SetPosition(2, bottomRight);
        lineRenderer.SetPosition(3, bottomLeft);

    }
}
