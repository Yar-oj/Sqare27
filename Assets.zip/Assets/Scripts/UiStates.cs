using UnityEngine;

public interface IUiState
{
    IUiState Left();
    IUiState Right();
    void Enter();
}

public class FightState : IUiState
{
    public IUiState Left()
    {
        return this;
    }

    public IUiState Right()
    {
        return new ActState();
    }

    public void Enter()
    {
        BattleManager.Instance.OpenFightMenu();
    }
}

public class ActState : IUiState
{
    public IUiState Left()
    {
        return new FightState();
    }

    public IUiState Right()
    {
        return new ItemState();
    }

    public void Enter()
    {
        BattleManager.Instance.OpenActMenu();
    }
}

public class ItemState : IUiState
{
    public IUiState Left()
    {
        return new ActState();
    }

    public IUiState Right()
    {
        return new MercyState();
    }

    public void Enter()
    {
        BattleManager.Instance.OpenItemMenu();
    }
}

public class MercyState : IUiState
{
    public IUiState Left()
    {
        return new ItemState();
    }

    public IUiState Right()
    {
        return this;
    }

    public void Enter()
    {
        BattleManager.Instance.OpenMercyMenu();
    }
}