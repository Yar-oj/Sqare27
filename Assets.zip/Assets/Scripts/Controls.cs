using UnityEngine;

public enum ControlEvent
{
    Up, Right, Down, Left, Z, X
};

public class Controls : MonoBehaviour
{
    [SerializeField]
    private ControlEvent controlEvent;

    public void OnMouseDown()
    {
        BattleManager.isPressed = true;
        BattleManager.Instance.SwitchCotnrols(controlEvent);
    }

}
