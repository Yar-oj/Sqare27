using UnityEngine;

public class Buttons : MonoBehaviour
{
    public bool isActivE = false;

    public void SetActivE(bool isActivEE)
    {
        this.isActivE = isActivEE;
        if (this.isActivE)
        {
            this.GetComponent<SpriteRenderer>().color = UnityEngine.Color.green;
        }
        else{
            this.GetComponent<SpriteRenderer>().color = UnityEngine.Color.white;
        }
    }
}
