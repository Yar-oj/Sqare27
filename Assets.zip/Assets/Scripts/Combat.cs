using UnityEngine;

public class Combat : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
