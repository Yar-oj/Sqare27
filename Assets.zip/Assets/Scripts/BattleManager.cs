using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum BattleState
{
    Intro,
    PlayerTurn,
    MenuSelection,
    ActionResult,
    EnemyDialogue,
    BulletHell,
    Win,
    Lose
}

public class BattleManager : MonoBehaviour
{
    private const string PlayerTurnDialogId = "PlayerTurn";
    private const string EnemyDefaultDialogId = "EnemyDefault";
    private const string MenuFight = "Fight";
    private const string MenuAct = "Act";
    private const string MenuItem = "Item";
    private const string MenuMercy = "Mercy";

    bool intro = true;
    static public bool isPressed = false;
    public BattleText battleText;

    private int currentMenuIndex;
    private List<DialogItem> currentMenuItems = new List<DialogItem>();

    private BattleState currentState;
    private IUiState currentUiState;

    [Header("Тайминги хода врага")]
    [Tooltip("Сколько фраза врага висит на экране после того, как допечаталась")]
    public float enemyPhraseHoldTime = 1.2f;
    [Tooltip("Заглушка боя: сколько секунд \"идёт\" бой, пока он не реализован")]
    public float combatStubDuration = 1.0f;

    [Header("Ссылки на компоненты")]
    public BattleBox battleBox;
    public Player playerPlane;
    public Enemy enemy;
    public GameObject buttons;
    public GameObject StatusBar;

    public static BattleManager Instance { get; private set; }

    void Awake()
    {
        Instance = this;
        JsonReader.Load();
    }

    public List<Buttons> buttonsContainer = new List<Buttons>();

    public IEnumerator IntroRoutine(Vector3 targetPosition, Vector3 targetScale, float duration)
    {
        Vector3 startPosition = enemy.transform.position;
        Vector3 startScale = enemy.transform.localScale;
        float elapsed = 0f;

        yield return new WaitForSeconds(1f);

        enemy.obj.SetActive(false);
        yield return new WaitForSeconds(0.1f);
        enemy.obj.SetActive(true);
        yield return new WaitForSeconds(0.1f);
        enemy.obj.SetActive(false);
        yield return new WaitForSeconds(0.1f);
        enemy.obj.SetActive(true);

        yield return new WaitForSeconds(0.5f);

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            float smoothT = Mathf.SmoothStep(0f, 1f, t);

            enemy.transform.position = Vector3.Lerp(startPosition, targetPosition, smoothT);
            enemy.transform.localScale = Vector3.Lerp(startScale, targetScale, smoothT);

            yield return null;
        }

        buttons.SetActive(false);
        StatusBar.SetActive(false);
        yield return new WaitForSeconds(0.1f);
        buttons.SetActive(true);
        StatusBar.SetActive(true);
        yield return new WaitForSeconds(0.1f);
        buttons.SetActive(false);
        StatusBar.SetActive(false);
        yield return new WaitForSeconds(0.1f);
        buttons.SetActive(true);
        StatusBar.SetActive(true);
        yield return new WaitForSeconds(0.5f);

        if (battleBox != null)
        {
            battleBox.SetDimensions(new Vector2(0f, -1.7f), new Vector2(27f, 7f), 0.5f);
        }

        enemy.transform.position = targetPosition;
        enemy.transform.localScale = targetScale;

        yield return new WaitForSeconds(0.5f);
        ShowPlayerTurnText();
        intro = false;
    }

    public void SwitchCotnrols(ControlEvent controlEvent)
    {
        if (intro || currentState == BattleState.ActionResult
                || currentState == BattleState.EnemyDialogue
                || currentState == BattleState.BulletHell
                || currentState == BattleState.Win
                || currentState == BattleState.Lose)
        {
            isPressed = false;
            return;
        }

        switch (controlEvent)
        {
            case ControlEvent.Left:
                if (currentState == BattleState.PlayerTurn)
                {
                    currentUiState = currentUiState.Left();
                    UpdateButtons();
                }
                break;

            case ControlEvent.Right:
                if (currentState == BattleState.PlayerTurn)
                {
                    currentUiState = currentUiState.Right();
                    UpdateButtons();
                }
                break;

            case ControlEvent.Up:
                if (currentState == BattleState.MenuSelection)
                {
                    currentMenuIndex--;
                    UpdateMenuText();
                }
                break;

            case ControlEvent.Down:
                if (currentState == BattleState.MenuSelection)
                {
                    currentMenuIndex++;
                    UpdateMenuText();
                }
                break;

            case ControlEvent.Z:
                if (currentState == BattleState.PlayerTurn)
                {
                    // открывает OpenFightMenu / OpenActMenu / ... (как раньше)
                    currentUiState.Enter();
                }
                else if (currentState == BattleState.MenuSelection)
                {
                    ConfirmMenuSelection();
                }
                break;

            case ControlEvent.X:
                if (currentState == BattleState.MenuSelection)
                {
                    ReturnToPlayerTurn();
                }
                break;
        }

        isPressed = false;
    }

    private void UpdateButtons()
    {
        foreach (Buttons button in buttonsContainer)
        {
            button.SetActivE(false);
        }

        if (currentUiState is FightState)
        {
            buttonsContainer[0].SetActivE(true);
        }
        else if (currentUiState is ActState)
        {
            buttonsContainer[1].SetActivE(true);
        }
        else if (currentUiState is ItemState)
        {
            buttonsContainer[2].SetActivE(true);
        }
        else if (currentUiState is MercyState)
        {
            buttonsContainer[3].SetActivE(true);
        }
    }

    void Start()
    {
        enemy.obj.SetActive(false);
        buttons.SetActive(false);
        StatusBar.SetActive(false);
        StartCoroutine(IntroRoutine(new Vector3(0f, 7f, 0f), new Vector3(0.5f, 0.5f, 0f), 1.5f));
        currentState = BattleState.PlayerTurn;
        buttonsContainer = new List<Buttons>(buttons.GetComponentsInChildren<Buttons>());
        currentUiState = new FightState();
        UpdateButtons();
    }

    // =====================================================================
    //  Меню (тексты берутся из Dialogs.json)
    // =====================================================================

    public void OpenFightMenu() { OpenMenu(MenuFight); }
    public void OpenActMenu()   { OpenMenu(MenuAct); }
    public void OpenItemMenu()  { OpenMenu(MenuItem); }
    public void OpenMercyMenu() { OpenMenu(MenuMercy); }

    private void OpenMenu(string menuName)
    {
        currentMenuItems = JsonReader.GetMenu(menuName);

        if (currentMenuItems.Count == 0)
        {
            Debug.LogWarning($"[BattleManager] В Dialogs.json нет пунктов для меню '{menuName}'");
            return;
        }

        currentState = BattleState.MenuSelection;
        currentMenuIndex = 0;
        UpdateMenuText();
    }

    private void UpdateMenuText()
    {
        if (currentMenuItems.Count == 0) return;

        if (currentMenuIndex > currentMenuItems.Count - 1) currentMenuIndex = currentMenuItems.Count - 1;
        if (currentMenuIndex < 0) currentMenuIndex = 0;

        string text = "";
        for (int i = 0; i < currentMenuItems.Count; i++)
        {
            if (i == currentMenuIndex)
                text += "--->> ";

            text += currentMenuItems[i].dialogText + "\n";
        }

        battleText.ShowText(text);
    }

    private void ShowPlayerTurnText()
    {
        battleText.ShowText(JsonReader.GetText(PlayerTurnDialogId));
    }

    private void ReturnToPlayerTurn()
    {
        currentState = BattleState.PlayerTurn;
        UpdateButtons();
        ShowPlayerTurnText();
    }

    // =====================================================================
    //  Ход врага: подтверждение -> фраза врага -> бой (заглушка) -> ход игрока
    // =====================================================================

    private void ConfirmMenuSelection()
    {
        if (currentMenuItems.Count == 0) return;

        DialogItem chosen = currentMenuItems[currentMenuIndex];
        StartCoroutine(EnemyTurnRoutine(chosen));
    }

    private IEnumerator EnemyTurnRoutine(DialogItem chosen)
    {
        Debug.Log($"[Turn] Игрок подтвердил: {chosen.menu} / {chosen.dialogId} ({chosen.dialogText})");

        // 1. Ход врага: его фраза (dialogData выбранного пункта, иначе общая фраза)
        currentState = BattleState.EnemyDialogue;
        Debug.Log("[Turn] Ход врага начался");

        string phrase = chosen.dialogData;
        if (string.IsNullOrEmpty(phrase))
            phrase = JsonReader.GetText(EnemyDefaultDialogId);

        battleText.ShowText(phrase);
        yield return new WaitUntil(() => !battleText.IsTyping);
        yield return new WaitForSeconds(enemyPhraseHoldTime);

        

        // 2. Бой (пока не реализован - только лог)
        currentState = BattleState.BulletHell;
        battleText.ShowText("");
        yield return StartCoroutine(CombatRoutine());

        // 3. Обратно к игроку
        Debug.Log("[Turn] Ход игрока");
        ReturnToPlayerTurn();
    }

    private IEnumerator CombatRoutine()
    {
        // TODO: сюда придёт настоящий бой (bullet hell)
        Debug.Log("[Combat] Бой начался");
        yield return new WaitForSeconds(combatStubDuration);
        Debug.Log("[Combat] Бой закончился");
    }
}
