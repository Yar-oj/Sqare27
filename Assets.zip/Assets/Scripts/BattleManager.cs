using NUnit.Framework;
using NUnit.Framework.Internal;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using UnityEngine;

public enum BattleState
{
    Intro,
    PlayerTurn,
    MenuSelection,
    ActionResult,
    EnemyDialogue,
    BulletHell,
    Win,
    Lose
}
public class BattleManager : MonoBehaviour
{
    bool intro = true;
    static public bool isPressed = false;
    public BattleText battleText;

    private int currentMenuIndex;
    private List<string> currentMenuItems;
    bool playerTurnFirst = true;

    private BattleState currentState;
    private IUiState currentUiState;


    [Header("Ссылки на компоненты")]
    public BattleBox battleBox;
    public Player playerPlane;
    public Enemy enemy;
    public GameObject buttons;
    public GameObject StatusBar;

    public static BattleManager Instance { get; private set; }

    void Awake()
    {
        Instance = this;
    }

    public List<Buttons> buttonsContainer = new List<Buttons>();

    public IEnumerator IntroRoutine(Vector3 targetPosition, Vector3 targetScale, float duration)
    {
        Vector3 startPosition = enemy.transform.position;
        Vector3 startScale = enemy.transform.localScale;
        float elapsed = 0f;

        yield return new WaitForSeconds(1f);

        enemy.obj.SetActive(false);
        yield return new WaitForSeconds(0.1f);
        enemy.obj.SetActive(true);
        yield return new WaitForSeconds(0.1f);
        enemy.obj.SetActive(false);
        yield return new WaitForSeconds(0.1f);
        enemy.obj.SetActive(true);


        yield return new WaitForSeconds(0.5f);



        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            float smoothT = Mathf.SmoothStep(0f, 1f, t);

            enemy.transform.position = Vector3.Lerp(startPosition, targetPosition, smoothT);
            enemy.transform.localScale = Vector3.Lerp(startScale, targetScale, smoothT);

            yield return null;
        }

        buttons.SetActive(false);
        StatusBar.SetActive(false);
        yield return new WaitForSeconds(0.1f);
        buttons.SetActive(true);
        StatusBar.SetActive(true);
        yield return new WaitForSeconds(0.1f);
        buttons.SetActive(false);
        StatusBar.SetActive(false);
        yield return new WaitForSeconds(0.1f);
        buttons.SetActive(true);
        StatusBar.SetActive(true);
        yield return new WaitForSeconds(0.5f);

        if (battleBox != null)
        {
            battleBox.SetDimensions(new Vector2(0f, -1.7f), new Vector2(27f, 7f), 0.5f);
        }

        enemy.transform.position = targetPosition;
        enemy.transform.localScale = targetScale;

        yield return new WaitForSeconds(0.5f);
        battleText.ShowText("Бой начинается");
        intro = false;
    }

    public void SwitchCotnrols(ControlEvent controlEvent)
    {

        switch (controlEvent)
        {
            case ControlEvent.Left:
                currentUiState = currentUiState.Left();
                UpdateButtons();
                break;

            case ControlEvent.Right:
                currentUiState = currentUiState.Right();
                UpdateButtons();
                break;

            case ControlEvent.Up:
                currentMenuIndex--;
                UpdateMenuText();
                break;

            case ControlEvent.Down:
                currentMenuIndex++;
                UpdateMenuText();
                break;

            case ControlEvent.Z:
                if(currentState == BattleState.PlayerTurn){
                currentUiState.Enter();
                }
                else if (currentState == BattleState.MenuSelection)
                {
                    
                }
                break;
            case ControlEvent.X:
                currentState = BattleState.PlayerTurn;
                UpdateButtons();
                battleText.ShowText("Бой начинается");
                break;  
        }

        isPressed = false;
    }
    private void UpdateButtons()
    {
        foreach (Buttons button in buttonsContainer)
        {
            button.SetActivE(false);
        }

        if (currentUiState is FightState)
        {
            buttonsContainer[0].SetActivE(true);
        }
        else if (currentUiState is ActState)
        {
            buttonsContainer[1].SetActivE(true);
        }
        else if (currentUiState is ItemState)
        {
            buttonsContainer[2].SetActivE(true);
        }
        else if (currentUiState is MercyState)
        {
            buttonsContainer[3].SetActivE(true);
        }
    }

    void Start()
    {
        enemy.obj.SetActive(false);
        buttons.SetActive(false);
        StatusBar.SetActive(false);
        StartCoroutine(IntroRoutine(new Vector3(0f, 7f, 0f), new Vector3(0.5f, 0.5f, 0f), 1.5f));
        currentState = BattleState.PlayerTurn;
        buttonsContainer = new List<Buttons>(buttons.GetComponentsInChildren<Buttons>());
        currentUiState = new FightState();
        UpdateButtons();

    }

    void Update()
    {
        if (!intro)
        {
            if (currentState == BattleState.MenuSelection)
            {
                
            }
        }
    }







    public void OpenFightMenu()
    {
        currentState = BattleState.MenuSelection;

        currentMenuItems = new List<string>()
    {
        "     СУ-27",
    };

        currentMenuIndex = 0;

        UpdateMenuText();
    }
    public void OpenActMenu()
    {
        currentState = BattleState.MenuSelection;

        currentMenuItems = new List<string>()
    {
        "     Включить СПО",
        "     Связаться с ДРЛО",
    };

        currentMenuIndex = 0;

        UpdateMenuText();
    }
    public void OpenItemMenu()
    {
        currentState = BattleState.MenuSelection;

        currentMenuItems = new List<string>()
    {
        "     Отстрел ЛТЦ - 12 шт",
        "     Отстрел ЛТЦ - 12 шт",
        "     Отстрел ЛТЦ - 12 шт",
    };

        currentMenuIndex = 0;

        UpdateMenuText();
    }
    public void OpenMercyMenu()
    {
        currentState = BattleState.MenuSelection;

        currentMenuItems = new List<string>()
    {
        "     Попробовать уйти",
    };

        currentMenuIndex = 0;

        UpdateMenuText();
    }
    private void UpdateMenuText()
    {
        string text = "";
        if (currentMenuItems.Count - 1 < currentMenuIndex){currentMenuIndex = currentMenuItems.Count-1;}
        if (currentMenuIndex < 0){currentMenuIndex = 0;}

        for (int i = 0; i < currentMenuItems.Count; i++)
        {
            if (i == currentMenuIndex)
                text += "--->> ";

            text += currentMenuItems[i].Substring(5) + "\n";
        }

        battleText.ShowText(text);
    }

}
