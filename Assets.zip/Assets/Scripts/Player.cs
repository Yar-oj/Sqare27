using UnityEngine;
public class Inventory
{

}
public class Actions
{

}

public class Player : MonoBehaviour
{
    
    public int Health { get; set; }
    public Inventory Inventory { get; set; }
    public Actions Actions;

    [Header("Настрока Движения")]
    public float speed = 5f;
    public float xPos = 0f;
    public float yPos = 0f;

    [Header("Объекты")]
    public GameObject HealthBar;



    [Header("Текстура")]
    Sprite Texture;

    void MoveX(float X) {
        xPos += X;
    
    }
    void MoveY(float Y)
    {
        yPos += Y;
    }

    void Start()
    {

    }

    void Update()
    {
    }
}
