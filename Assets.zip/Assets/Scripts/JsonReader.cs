using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class DialogItem
{
    public string dialogId;
    public string menu;
    public string dialogText;
    public string dialogData;
}

[Serializable]
public class DialogWrapper
{
    public List<DialogItem> allDialogs;
}

public static class JsonReader
{
    private const string FileName = "Dialogs"; // без расширения

    private static DialogWrapper dialogData;
    private static Dictionary<string, DialogItem> byId;

    public static void Load()
    {
        dialogData = null;
        byId = new Dictionary<string, DialogItem>();

        TextAsset asset = Resources.Load<TextAsset>(FileName);
        if (asset == null)
        {
            Debug.LogError($"[JsonReader] Не найден файл Resources/{FileName}.json");
            dialogData = new DialogWrapper { allDialogs = new List<DialogItem>() };
            return;
        }

        dialogData = JsonUtility.FromJson<DialogWrapper>(asset.text);
        if (dialogData == null || dialogData.allDialogs == null)
        {
            Debug.LogError("[JsonReader] Dialogs.json пустой или имеет неверный формат");
            dialogData = new DialogWrapper { allDialogs = new List<DialogItem>() };
            return;
        }

        foreach (DialogItem item in dialogData.allDialogs)
        {
            if (string.IsNullOrEmpty(item.dialogId)) continue;
            byId[item.dialogId] = item;
        }
    }

    private static void EnsureLoaded()
    {
        if (dialogData == null) Load();
    }

    public static DialogItem GetItem(string dialogId)
    {
        EnsureLoaded();
        byId.TryGetValue(dialogId, out DialogItem item);
        return item;
    }

    public static string GetText(string dialogId, string fallback = "")
    {
        DialogItem item = GetItem(dialogId);
        if (item == null || string.IsNullOrEmpty(item.dialogData))
        {
            if (item == null) Debug.LogWarning($"[JsonReader] Диалог '{dialogId}' не найден");
            return fallback;
        }
        return item.dialogData;
    }

    public static List<DialogItem> GetMenu(string menuName)
    {
        EnsureLoaded();
        List<DialogItem> result = new List<DialogItem>();
        foreach (DialogItem item in dialogData.allDialogs)
        {
            if (item.menu == menuName) result.Add(item);
        }
        return result;
    }
}
