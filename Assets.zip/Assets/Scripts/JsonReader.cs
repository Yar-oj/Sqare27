using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using static UnityEngine.Audio.IAudioGenerator;

[Serializable]
public class DialogItem
{
    public string dialogId;
    public string dialogText;
    public string dialogData;
}

[Serializable]
public class DialogWrapper
{
    public List<DialogItem> allDialogs;
}


public class JsonReader : MonoBehaviour
{

    private DialogWrapper dialogData;

    private void LoadDialogs(string fileName)
    {
        string filePath = Path.Combine(Application.streamingAssetsPath, fileName);

        if (File.Exists(filePath))
        {
            string jsonText = File.ReadAllText(filePath);

            dialogData = JsonUtility.FromJson<DialogWrapper>(jsonText);
        }
    }
}
