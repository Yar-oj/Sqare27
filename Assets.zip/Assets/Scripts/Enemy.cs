using UnityEngine;

public class Enemy : MonoBehaviour
{
    [Header("Объект")]
    public GameObject obj;
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
