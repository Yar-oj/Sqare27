using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class BattleText : MonoBehaviour
{
    [SerializeField] private TextMesh textField;
    [SerializeField] private AudioSource audioSource;

    public float letterDelay = 0.03f;

    private Coroutine typingCoroutine;
    private bool isTyping;

    public bool IsTyping => isTyping;

    public void ShowText(string text)
    {
        if (typingCoroutine != null)
        {
            StopCoroutine(typingCoroutine);
        }

        typingCoroutine = StartCoroutine(TypeText(text));
    }

    private IEnumerator TypeText(string text)
    {
        isTyping = true;
        textField.text = "";

        foreach (char c in text)
        {
            textField.text += c;

            if (c != ' ')
            {
                audioSource.pitch = Random.Range(0.95f, 1.05f);
                audioSource.PlayOneShot(audioSource.clip);
            }

            yield return new WaitForSeconds(letterDelay);
        }

        isTyping = false;
    }

    public void Skip(string fullText)
    {
        if (!isTyping)
            return;

        StopCoroutine(typingCoroutine);

        textField.text = fullText;

        isTyping = false;
    }
}