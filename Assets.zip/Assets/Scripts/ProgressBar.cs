using Unity.VisualScripting;
using UnityEngine;

public class ProgressBar : MonoBehaviour
{


    [Header("Значения")]

    [SerializeField]
    private float minValue;
    [SerializeField]
    private float maxValue;
    [SerializeField]
    private float value;

    public float MinValue
    {
        get => minValue;
        set 
        {
            minValue = value;
            Recalculate();
        }
    }
    public float MaxValue
    {
        get => maxValue;
        set
        {
            maxValue = value;
            Recalculate();
        }
    }
    public float Value
    {
        get => value;
        set
        {
            this.value = value;
            Recalculate();
        }
    }
    [SerializeField]
    private GameObject bar;

    void Start()
    {
        Recalculate();
    }
    void Update()
    {

    }

    private void OnValidate()
    {
        MinValue = minValue;
        MaxValue = maxValue;
        Value = value;
    }

    private void Recalculate()
    {
        float xScale = Mathf.Clamp((value - minValue) / (maxValue - minValue), 0.0f, 1.0f);
        Vector3 scale = bar.transform.localScale;
        scale.x = xScale;
        bar.transform.localScale = scale;
    }
}
